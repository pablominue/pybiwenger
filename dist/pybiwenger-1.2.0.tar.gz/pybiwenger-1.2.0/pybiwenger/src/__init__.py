"""Base Client for the Biwenger API."""

from .client.client import BiwengerBaseClient
